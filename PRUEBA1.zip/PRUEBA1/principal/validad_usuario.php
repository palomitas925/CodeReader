<?php
header('Content-Type: application/json');
$data = json_decode(file_get_contents("php://input"), true);

$usuario = $data['usuario'];
$contrasena = $data['contrasena'];

$conn = new mysqli("localhost", "Omars", "Buycraf7", "popcode");

if ($conn->connect_error) {
  echo json_encode(["exito" => false, "error" => "Conexión fallida"]);
  exit;
}

$sql = "SELECT rol_colaborador, area FROM usuarios WHERE no_colaborador = ? AND contraseña = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $usuario, $contrasena);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
  echo json_encode([
    "exito" => true,
    "rol" => $row["rol_colaborador"],
    "area" => $row["area"]
  ]);
} else {
  echo json_encode(["exito" => false]);
}

$conn->close();
?>
